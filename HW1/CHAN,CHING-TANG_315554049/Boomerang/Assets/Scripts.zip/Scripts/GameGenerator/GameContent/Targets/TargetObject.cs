using System.Collections;
using UnityEngine;

public class TargetObject : MonoBehaviour
{
    [Header("Hit Response")]
    public float pushForce = 8f;
    public float upwardForce = 3f;
    public float visibleAfterHit = 2f;
    public int scoreValue = 10;

    [Header("Audio")]
    public AudioClip hitSound;

    bool hit;

    public void OnHitByBoomerang(Vector3 fromPosition)
    {
        if (hit) return;
        hit = true;

        if (hitSound) AudioSource.PlayClipAtPoint(hitSound, transform.position);

        var rb = GetComponent<Rigidbody>();
        if (rb)
        {
            Vector3 dir = (transform.position - fromPosition).normalized;
            rb.AddForce(dir * pushForce + Vector3.up * upwardForce, ForceMode.Impulse);
            rb.AddTorque(Random.insideUnitSphere * pushForce, ForceMode.Impulse);
        }

        if (ScoreManager.Instance)
            ScoreManager.Instance.AddTargetScore(scoreValue);

        StartCoroutine(DisappearAfterDelay());
    }

    IEnumerator DisappearAfterDelay()
    {
        yield return new WaitForSeconds(visibleAfterHit);
        Destroy(gameObject);
    }

    void OnDisable()
    {
        // 被打中之後兩秒內玩家踏上平台的話，SetActive(false) 會直接中止協程，
        // 這個物件就永遠不會被 Destroy，離開平台後會變成一個打不中的殭屍目標。
        // 這裡直接收掉，補生成機制會補一個新的回來。
        if (hit) Destroy(gameObject);
    }
}